package com.example.moco;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class AnnouncementlistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcementlist);
    }
}